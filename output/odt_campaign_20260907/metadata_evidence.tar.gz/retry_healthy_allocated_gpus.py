import os,json,subprocess,pathlib,datetime
root=pathlib.Path('/work/joy/x-vla-odt-campaign-20260907-v1')
allocated=os.environ['CUDA_VISIBLE_DEVICES'].split(',')
if len(allocated)!=3 or len(set(allocated))!=3:raise RuntimeError('Expected exactly three allocated GPU identities')
records=[]
for device in allocated:
 p=subprocess.run(['nvidia-smi','--id='+device,'--query-gpu=name,uuid,compute_mode','--format=csv,noheader'],capture_output=True,text=True,timeout=30)
 records.append({'allocated_device':device,'returncode':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
healthy=[r['allocated_device'] for r in records if r['returncode']==0 and r['stdout'].strip().startswith('Quadro RTX 6000,') and 'Prohibited' not in r['stdout'] and 'ERR' not in r['stdout']]
receipt={'slurm_job_id':os.environ['SLURM_JOB_ID'],'slurm_job_gpus':os.environ.get('SLURM_JOB_GPUS'),'cuda_visible_devices':os.environ['CUDA_VISIBLE_DEVICES'],'health_checks':records,'selected':healthy[:2],'criterion':'successful GPU management query and correct model, before any model or episode construction','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
p=root/'rollout_rtx6000_v1'/'healthy_device_retry.json'
with p.open('x') as f:json.dump(receipt,f,indent=2)
print(json.dumps(receipt),flush=True)
if len(healthy)<2:raise RuntimeError('Fewer than two healthy allocated RTX 6000 GPUs')
children=[]
for index,device in zip((33,34),healthy[:2]):
 env=dict(os.environ,CUDA_VISIBLE_DEVICES=device,SLURM_ARRAY_TASK_ID=str(index),ODT_ROLLOUT_ROOT=str(root/'rollout_rtx6000_v1'),ODT_ROLLOUT_MODE='worker',ODT_SMOKE_SHA256='044d10e663805900d2e24fd0f735e54dc99fa4ab91b5c730e9c3b9f0113bfb48')
 children.append((index,subprocess.Popen(['bash',str(root/'rollout_rtx6000_v1/scripts/slurm_odt_ffn_rollout_v1.sh')],env=env)))
statuses={str(index):child.wait() for index,child in children}
with (root/'rollout_rtx6000_v1'/'healthy_device_retry_exit.json').open('x') as f:json.dump(statuses,f,indent=2)
if any(statuses.values()):raise RuntimeError('Retry worker failed: '+str(statuses))
