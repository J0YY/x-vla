#!/bin/bash
set -euo pipefail
cd /work/joy/x-vla-odt-campaign-20260907-v1/rollout_summary_v1
export PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
sha256sum --check sources.sha256
exec /work/joy/safesae/bin/python -u -m scripts.odt_rollout_summary_v1 --rollout /work/joy/x-vla-odt-campaign-20260907-v1/rollout_rtx6000_v1 --training /work/joy/x-vla-capable-linear-b1c0-odt-v2/inputs/capable_linear_training.json --output /work/joy/x-vla-odt-campaign-20260907-v1/rollout_summary_v1/rtx6000_results
